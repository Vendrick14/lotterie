#include "rclcpp/rclcpp.hpp"
#include "mas_solarsystem/celestial_body.h"

int main(int argc, char** argv) {
  rclcpp::init(argc, argv);
  auto node = std::make_shared<rclcpp::Node>("user_env_node");

  CelestialBody sun("sun", 695700.0, 0.0, 0.0, 0.0);  // Initialize the sun

  CelestialBody mercury("mercury", 2439.7, 57900000.0, 760055.0, 0.03);
  CelestialBody venus("venus", 6051.8, 108200000.0, 1941392.0, 177.36);
  CelestialBody earth("earth", 6371.0, 149600000.0, 31558149.76, 23.44);
  CelestialBody mars("mars", 3389.5, 227900000.0, 59355067.2, 25.19);
  CelestialBody jupiter("jupiter", 69911.0, 778300000.0, 374347972.0, 3.13);
  CelestialBody saturn("saturn", 58232.0, 1400000000.0, 929598672.0, 26.73);
  CelestialBody uranus("uranus", 25362.0, 2900000000.0, 2651302208.0, 97.77);
  CelestialBody neptune("neptune", 24622.0, 4500000000.0, 5200418592.0, 28.32);

  rclcpp::Rate loop_rate(10);  // 10 Hz update rate

  while (rclcpp::ok()) {
    double time = node->get_clock()->now().seconds();  // Current simulation time in seconds

    sun.update(time);
    mercury.update(time);
    venus.update(time);
    earth.update(time);
    mars.update(time);
    jupiter.update(time);
    saturn.update(time);
    uranus.update(time);
    neptune.update(time);

    // Publish marker and transform messages for each celestial body
    sun.publishMarker();
    sun.publishTransform();

    mercury.publishMarker();
    mercury.publishTransform();

    venus.publishMarker();
    venus.publishTransform();

    earth.publishMarker();
    earth.publishTransform();

    mars.publishMarker();
    mars.publishTransform();

    jupiter.publishMarker();
    jupiter.publishTransform();

    saturn.publishMarker();
    saturn.publishTransform();

    uranus.publishMarker();
    uranus.publishTransform();

    neptune.publishMarker();
    neptune.publishTransform();


    rclcpp::spin_some(node);
    loop_rate.sleep();
  }

  rclcpp::shutdown();
  return 0;
}
