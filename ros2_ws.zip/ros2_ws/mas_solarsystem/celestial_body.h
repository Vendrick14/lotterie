#pragma once

#include <string>
#include <visualization_msgs/msg/marker.hpp>
#include <geometry_msgs/msg/transform_stamped.hpp>

class CelestialBody {
public:
  CelestialBody(const std::string& name, double radius, double distance, double period, double inclination);
  void update(double time);

private:
  std::string name_;
  double radius_;
  double distance_;
  double period_;
  double inclination_;

  visualization_msgs::msg::Marker marker_;
  geometry_msgs::msg::TransformStamped transform_;
};

