import launch
import launch_ros.actions as ros_actions

def generate_launch_description():
    # Définition des actions pour chaque nœud

    # Nœud pour le système solaire
    solarsystem_node = ros_actions.Node(
        package='mas_solarsystem',
        node_executable='solarsystem_node',
        output='screen'
    )

    # Nœud pour l'environnement utilisateur
    userenv_node = ros_actions.Node(
        package='mas_solarsystem',
        node_executable='user_env_node',
        output='screen'
    )

    # Définition de la description du lancement
    ld = launch.LaunchDescription()

    # Ajout des actions des nœuds à la description du lancement
    ld.add_action(solarsystem_node)
    ld.add_action(userenv_node)

    return ld
