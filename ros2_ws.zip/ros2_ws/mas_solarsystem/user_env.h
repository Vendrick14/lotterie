#ifndef MAS_SOLARSYSTEM_USER_ENV_H
#define MAS_SOLARSYSTEM_USER_ENV_H

#include <rclcpp/rclcpp.hpp>
#include <std_srvs/srv/Trigger.hpp>
#include <mas_solarsystem/PlanetPosition.hpp>

class UserEnv : public rclcpp::Node
{
public:
  UserEnv();

private:
  void initializeParameters();
  void setupPublishers();
  void setupSubscribers();
  void setupServices();

  bool resetSimulationCallback(const std::shared_ptr<std_srvs::srv::Trigger::Request> request,
                               std::shared_ptr<std_srvs::srv::Trigger::Response> response);

  void publishPlanetPositions();

  // Publishers
  rclcpp::Publisher<mas_solarsystem::PlanetPosition>::SharedPtr planet_position_pub_;

  // Subscribers

  // Services
  rclcpp::Service<std_srvs::srv::Trigger>::SharedPtr reset_sim_service_;

  // Parameters
  double space_scale_;
  double time_scale_;
};

#endif  // MAS_SOLARSYSTEM_USER_ENV_H
