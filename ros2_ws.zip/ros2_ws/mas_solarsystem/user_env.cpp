#include "mas_solarsystem/user_env.h"

UserEnv::UserEnv() : Node("user_env")
{
  initializeParameters();
  setupPublishers();
  setupSubscribers();
  setupServices();
}

void UserEnv::initializeParameters()
{
  // Initialize parameters from the YAML file or set default values
  this->declare_parameter("space_scale", 1.0);
  this->declare_parameter("time_scale", 1.0);

  // Get parameter values
  this->get_parameter("space_scale", space_scale_);
  this->get_parameter("time_scale", time_scale_);
}

void UserEnv::setupPublishers()
{
  planet_position_pub_ = this->create_publisher<mas_solarsystem::PlanetPosition>("planet_positions", 10);
}

void UserEnv::setupSubscribers()
{
  // Setup any necessary subscribers
}

void UserEnv::setupServices()
{
  reset_sim_service_ = this->create_service<std_srvs::srv::Trigger>("reset_sim",
                                                                   std::bind(&UserEnv::resetSimulationCallback, this,
                                                                             std::placeholders::_1,
                                                                             std::placeholders::_2));
}

bool UserEnv::resetSimulationCallback(const std::shared_ptr<std_srvs::srv::Trigger::Request> request,
                                      std::shared_ptr<std_srvs::srv::Trigger::Response> response)
{
  // Implement the reset simulation functionality here
  // ...

  response->success = true;
  response->message = "Simulation reset";
  return true;
}

void UserEnv::publishPlanetPositions()
{
  // Publish the positions of the Earth and Mars
  mas_solarsystem::PlanetPosition earth_position;
  // Set the position of the Earth
  // ...

  mas_solarsystem::PlanetPosition mars_position;
  // Set the position of Mars
  // ...

  planet_position_pub_->publish(earth_position);
  planet_position_pub_->publish(mars_position);
}
