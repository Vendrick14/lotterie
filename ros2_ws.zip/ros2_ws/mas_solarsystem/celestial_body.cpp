#include "mas_solarsystem/celestial_body.h"
#include <visualization_msgs/msg/marker.hpp>
#include <tf2_ros/transform_broadcaster.h>
#include <geometry_msgs/msg/transform_stamped.hpp>
#include <std_msgs/msg/float64.hpp>
#include <cmath>

CelestialBody::CelestialBody(const std::string& name, double radius, double distance, double period, double inclination)
  : name_(name), radius_(radius), distance_(distance), period_(period), inclination_(inclination)
{
  // Initialize marker
  marker_.header.frame_id = "sun";  // Assuming the sun as the fixed frame
  marker_.id = 0;
  marker_.type = visualization_msgs::msg::Marker::SPHERE;
  marker_.action = visualization_msgs::msg::Marker::ADD;
  marker_.pose.position.x = 0.0;
  marker_.pose.position.y = 0.0;
  marker_.pose.position.z = 0.0;
  marker_.pose.orientation.x = 0.0;
  marker_.pose.orientation.y = 0.0;
  marker_.pose.orientation.z = 0.0;
  marker_.pose.orientation.w = 1.0;
  marker_.scale.x = radius_ * 2.0;
  marker_.scale.y = radius_ * 2.0;
  marker_.scale.z = radius_ * 2.0;
  marker_.color.r = 1.0;  // Red color (you can modify this as needed)
  marker_.color.g = 0.0;
  marker_.color.b = 0.0;
  marker_.color.a = 1.0;

  // Initialize transform
  transform_.header.frame_id = "sun";  // Assuming the sun as the fixed frame
  transform_.child_frame_id = name_;
  transform_.transform.translation.x = distance_;
  transform_.transform.translation.y = 0.0;
  transform_.transform.translation.z = 0.0;
  transform_.transform.rotation.x = 0.0;
  transform_.transform.rotation.y = 0.0;
  transform_.transform.rotation.z = 0.0;
  transform_.transform.rotation.w = 1.0;
}

void CelestialBody::update(double time) {
  double angle = 2.0 * M_PI * time / period_;
  double x = distance_ * cos(angle);
  double y = distance_ * sin(angle);
  double z = distance_ * sin(inclination_) * sin(angle);

  marker_.pose.position.x = x;
  marker_.pose.position.y = y;
  marker_.pose.position.z = z;

  transform_.transform.translation.x = x;
  transform_.transform.translation.y = y;
  transform_.transform.translation.z = z;
}
