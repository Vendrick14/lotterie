import os
from glob import glob
from setuptools import setup, find_packages

package_name = 'robot_nano_hand_teleop'

setup(
    name=package_name,
    version='0.1.0',
    packages=find_packages(),
    data_files=[
        ('share/' + package_name, ['package.xml']),
        (os.path.join('share', package_name, 'launch'), glob('launch/*.launch.py')),
        (os.path.join('share', package_name, 'urdf'), glob('urdf/*.urdf.xml')),
        (os.path.join('share', package_name, 'models'), glob('models/*.stl')),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='Adrian',
    maintainer_email='adrian.broussy@gmail.com',
    description='ROS 2 package for controlling the robot nano hand',
    license='TODO: License declaration',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'state_publisher = robot_nano_hand_teleop.state_publisher:main',
        ],
    },
)
